notes
-----

planned features
-allow users to "watch" a course that's already full (from reservations), ie. be notified when the course has free slots